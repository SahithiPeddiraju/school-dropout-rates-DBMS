<?php
$conn = mysqli_connect( "localhost","root","","dropout");
if(!$conn){
echo "Not Working";
}
?>